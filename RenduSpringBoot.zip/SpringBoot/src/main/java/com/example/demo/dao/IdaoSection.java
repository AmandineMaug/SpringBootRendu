package com.example.demo.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface IdaoSection<T> extends IdaoCRUD<T>{

}
