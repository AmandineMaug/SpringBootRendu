package com.example.demo.service;

import java.util.List;

import com.example.demo.entities.Matiere;

public class serviceMatiere implements IserviceMatiere {

	@Override
	public Matiere findOneById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Matiere save(Matiere p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Matiere p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Matiere> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
