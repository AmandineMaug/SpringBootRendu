package com.example.demo.service;

import java.util.List;

import com.example.demo.entities.Laboratoire;

public class serviceLaboratoire implements IserviceLaboratoire {

	@Override
	public Laboratoire findOneById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Laboratoire save(Laboratoire p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Laboratoire p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Laboratoire> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
