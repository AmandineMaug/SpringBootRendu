package com.example.demo.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface IdaoMatiere<T> extends IdaoCRUD<T> {

}
