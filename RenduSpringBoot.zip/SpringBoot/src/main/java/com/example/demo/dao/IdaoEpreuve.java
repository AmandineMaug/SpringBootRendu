package com.example.demo.dao;




import org.springframework.stereotype.Repository;


@Repository
public interface IdaoEpreuve<T> extends IdaoCRUD<T> {

	
}
