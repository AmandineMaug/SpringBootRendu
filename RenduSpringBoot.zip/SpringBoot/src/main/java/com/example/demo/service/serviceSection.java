package com.example.demo.service;

import java.util.List;

import com.example.demo.entities.Section;

public class serviceSection implements IserviceSection {

	@Override
	public Section findOneById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Section save(Section p) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delete(Section p) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Section> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
